export class User {
    userId: string;
    emails: string;
    names: string;
    usernames: string;
    emailVerified: boolean;
    password: string;
    location: string;


    constructor(
        userId: string,
        emails: string,
        names: string,
        usernames: string,
        emailVerified: boolean
    ) {
    }
}
